#!/bin/bash
# CVE-2022-0847 Dirty Pipe exploit attempt
if [ -w /proc/version ]; then
    echo "System may be vulnerable to Dirty Pipe"
    echo "root:x:0:0:root:/root:/bin/bash" > /tmp/test_passwd
    if [ $? -eq 0 ]; then
        echo "Write successful - potential privilege escalation"
    fi
fi

