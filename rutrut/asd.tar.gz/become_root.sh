#!/bin/bash
chmod +s /bin/bash

