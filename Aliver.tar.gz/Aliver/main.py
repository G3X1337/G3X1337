import requests
import time
import configparser
import logging
import os
import sys
import re
from datetime import datetime
from bs4 import BeautifulSoup
from colorama import Fore, Style, init
from urllib.parse import urlparse
import urllib3
import concurrent.futures
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich import box

# --- NONAKTIFKAN PERINGATAN SSL ---
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Inisialisasi rich console
console = Console()

# --- USER-AGENT KHUSUS GOOGLEBOT ---
GOOGLEBOT_UA = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'
# User-Agent untuk browser biasa
BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'

# --- SETUP KONFIGURASI ---
config = configparser.ConfigParser()
try:
    config.read('config.ini')

    # Baca pengaturan umum
    DOMAINS_FILE = config['settings']['domains_file']
    CHECK_INTERVAL = int(config['settings']['check_interval_seconds'])
    LOG_FILE = config['settings']['log_file']
    REQUEST_TIMEOUT = int(config['settings']['request_timeout'])
    DOMAIN_FILES_DIR = config['settings'].get('domain_files_dir', 'domain_files')

    # Baca pengaturan Telegram
    ENABLE_ALERTS = config.getboolean('telegram_alerts', 'enable_alerts', fallback=False)
    TELEGRAM_BOT_TOKEN = config['telegram_alerts']['bot_token']
    TELEGRAM_CHAT_ID = config['telegram_alerts']['chat_id']
    ALERT_COOLDOWN_SECONDS = int(config['telegram_alerts']['alert_cooldown_seconds'])

except (KeyError, FileNotFoundError) as e:
    console.print(f"[red]Error: File config.ini tidak ditemukan atau tidak lengkap. {e}[/red]")
    sys.exit(1)

# --- SETUP LOGGING ---
log_dir = os.path.dirname(LOG_FILE)
if log_dir and not os.path.exists(log_dir):
    os.makedirs(log_dir)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE)
    ]
)

# --- FUNGSI BARU: PENDETEKSI WEBSITE RESTORE ---
def check_website_restore_status(file_status, main_page_response, main_page_soup):
    """
    Mendeteksi apakah website kemungkinan besar telah di-restore atau di-reset.
    """
    is_restored = False

    if "Missing:" in file_status or "Missing (Redirect)" in file_status:
        is_restored = True
        logging.info(f"[RESTORE CHECK] Triggered by missing file: {file_status}")

    if main_page_response and main_page_response.status_code == 403:
        is_restored = True
        logging.info(f"[RESTORE CHECK] Triggered by 403 Forbidden status.")

    if main_page_response and main_page_response.status_code == 200 and main_page_soup:
        page_text = main_page_soup.get_text().lower()
        title_text = main_page_soup.title.get_text().lower() if main_page_soup.title else ""

        if "index of /" in page_text or "directory listing for" in page_text or "index of /" in title_text:
            is_restored = True
            logging.info(f"[RESTORE CHECK] Triggered by directory listing.")

    if main_page_response and main_page_response.status_code == 200 and main_page_soup and main_page_soup.title:
        title = main_page_soup.title.get_text().strip()
        default_titles = [
            "apache2 ubuntu default page", "welcome to nginx!", "test page for nginx http server",
            "iis windows server", "default web site page"
        ]
        if any(dt in title.lower() for dt in default_titles):
            is_restored = True
            logging.info(f"[RESTORE CHECK] Triggered by default server page: '{title}'")

    return "RESTORED" if is_restored else "OK"

# --- FUNGSI CEK FILE LIVE SERVER (DIMODIFIKASI UNTUK CEK HANYA ROOT DOMAIN) ---
def check_domain_file_status(domain):
    parsed_domain = urlparse(domain)
    # Ekstrak hanya bagian scheme dan netloc (hostname) dari URL
    base_domain = f"{parsed_domain.scheme}://{parsed_domain.netloc}"
    hostname = parsed_domain.netloc
    
    if not hostname:
        return "Invalid Domain URL"

    domain_dir = os.path.join(DOMAIN_FILES_DIR, hostname)
    if not os.path.isdir(domain_dir):
        return "Dir Not Found"

    local_files_relative_paths = []
    try:
        for dirpath, _, filenames in os.walk(domain_dir):
            for filename in filenames:
                relative_path = os.path.relpath(os.path.join(dirpath, filename), domain_dir)
                local_files_relative_paths.append(relative_path.replace(os.sep, '/'))
    except OSError as e:
        logging.warning(f"Tidak bisa membaca direktori {domain_dir}: {e}")
        return "Dir Error"

    if not local_files_relative_paths:
        return "OK (No Files to Check)"

    problems = []
    for file_path in local_files_relative_paths:
        if file_path.startswith('@root/'):
            filename = file_path.split('/', 1)[1]
            file_url = base_domain.rstrip('/') + '/' + filename.lstrip('/')
        else:
            # Gunakan base_domain bukan domain asli untuk memeriksa file
            file_url = base_domain.rstrip('/') + '/' + file_path.lstrip('/')

        try:
            response = requests.get(file_url, headers={'User-Agent': GOOGLEBOT_UA}, timeout=REQUEST_TIMEOUT, verify=False, allow_redirects=True, stream=True)
            response.close()

            if response.url != file_url:
                problems.append(f"Missing (Redirect): {file_path}")
                logging.info(f"Redirect detected for {file_url} -> {response.url}. Marking as missing.")
                continue

            if response.status_code == 404:
                problems.append(f"Missing: {file_path}")
            elif not response.ok:
                problems.append(f"Error ({response.status_code}): {file_path}")

        except requests.exceptions.Timeout:
            problems.append(f"Timeout: {file_path}")
        except requests.exceptions.RequestException as e:
            logging.debug(f"Request exception for {file_url}: {e}")
            problems.append(f"Conn Error: {file_path}")

    return "OK" if not problems else ", ".join(problems)

# --- FUNGSI PEWARNAAN ---
def get_color_for_status(status):
    if status == 'VALID':
        return 'green'
    elif status == 'CLOAKING DETECTED':
        return 'red'
    elif status in ['INVALID', 'NOT FOUND', 'DOMAIN ERROR', 'TIMEOUT', 'SSL ERROR', 'CONN ERROR']:
        return 'red'
    else:
        return 'white'

def get_color_for_code(code):
    if code == '-':
        return 'white'
    if code == 'CTO':
        return 'magenta'
    try:
        code_int = int(code)
        if code_int == 200:
            return 'green'
        elif code_int == 403:
            return 'blue'
        elif 500 <= code_int <= 503:
            return 'red'
        elif 300 <= code_int < 400:
            return 'cyan'
        elif 400 <= code_int < 500:
            return 'yellow'
        else:
            return 'white'
    except (ValueError, TypeError):
        return 'white'

def get_color_for_file_status(status):
    if "OK" == status or status.startswith("OK"):
        return 'green'
    elif "Missing" in status or "Error" in status or "Timeout" in status or "Conn Error" in status:
        return 'red'
    elif "Dir Not Found" in status or "Dir Error" in status:
        return 'yellow'
    else:
        return 'white'

def get_color_for_restore_status(status):
    if status == 'RESTORED':
        return 'bright_magenta'
    return 'green'

# --- FUNGSI ALERT TELEGRAM ---
def send_telegram_alert(domain, result):
    if not ENABLE_ALERTS:
        return
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logging.error("Token atau Chat ID Telegram tidak diatur dengan benar di config.ini.")
        return
    try:
        problems = []
        if result['amp_status'] == 'CLOAKING DETECTED':
            problems.append(f"Cloaking Detected")
        elif result['amp_status'] not in ['VALID', 'N/A']:
            problems.append(f"AMP {result['amp_status']}")
        if result['response_code'] in [403, 500, 502, 501, 503]:
            problems.append(f"HTTP: {result['response_code']}")
        if any(keyword in result['file_status'] for keyword in ["Missing", "Error", "Timeout", "Conn Error", "Dir Not Found"]):
            problems.append(f"File {result['file_status']}")

        if result['restore_status'] == 'RESTORED':
            problems.append("Website Restored/Reset")

        if result.get('amp_url_changed', False):
            problems.append(f"AMP URL Changed from {result.get('old_amp_url', 'N/A')} to {result.get('new_amp_url', 'N/A')}")

        if not problems:
            return
        problem_summary = ", ".join(problems)
        CENTER = "‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎"
        TOP_ALERT = f"{CENTER}<b>█████████  🚨 WEBSITE MONITOR ALERT 🚨  █████████</b>"
        TOP_DETAILS = f"{CENTER}<b>█████████████  📝 DETAILS 📝  █████████████</b>"
        TOP_DETAILSS = f"{CENTER}<b>██████████  📝 MORE DETAILS 📝  ██████████</b>"

        amp_url_details = ""
        if result.get('amp_url_changed', False):
            amp_url_details = (
                f"Old AMP URL : <b>{result.get('old_amp_url', 'N/A')}</b>\n"
                f"New AMP URL : <b>{result.get('new_amp_url', 'N/A')}</b>\n"
            )

        message = (
            f"{TOP_ALERT}\n\n"
            f"Domain : <b>{domain}</b>\n"
            f"Problem : <b>{problem_summary}</b>\n\n"
            f"{TOP_DETAILS}\n\n"
            f"Main Title : <b>{result['main_page_title']}</b>\n"
            f"AMP Title : <b>{result['amp_title']}</b>\n\n"
            f"{TOP_DETAILSS}\n\n"
            f"{amp_url_details}"
            f"Link Daftar/Masuk : <b>{result['daftar_masuk_link']}</b>\n"
            f"Restore Status: <b>{result['restore_status']}</b>\n"
            f"File Status : <b>{result['file_status']}</b>\n"
        )
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {'chat_id': TELEGRAM_CHAT_ID, 'text': message, 'parse_mode': 'HTML'}
        response = requests.post(url, json=payload, timeout=15)
        if response.status_code != 200:
            logging.error(f"Gagal mengirim alert! Status: {response.status_code}, Response: {response.text}")
        else:
            logging.info(f"Alert berhasil dikirim untuk {domain}")
    except Exception as e:
        logging.error(f"Error tak terduga saat mengirim alert ke Telegram untuk {domain}: {e}")

# --- FUNGSI PEMBANTU ---
def load_domains(filename):
    try:
        with open(filename, 'r') as f:
            domains = [line.strip() for line in f if line.strip()]
        return domains
    except FileNotFoundError:
        logging.error(f"Error: File {filename} tidak ditemukan.")
        return []

# --- FUNGSI UTAMA PENGECEKAN ---
def check_domain(domain):
    result = {
        'domain': domain,
        'file_status': '-',
        'restore_status': '-',
        'main_page_title': '-',
        'amp_url': 'Not Found',
        'amp_status': 'N/A',
        'amp_title': '-',
        'response_code': '-',
        'response_time_ms': '-',
        'daftar_masuk_link': '-',
    }

    main_page_response = None
    main_page_soup = None

    try:
        headers = {'User-Agent': GOOGLEBOT_UA}
        main_page_response = requests.get(domain, headers=headers, timeout=REQUEST_TIMEOUT, verify=False, allow_redirects=True)

        if main_page_response.status_code == 200:
            main_page_soup = BeautifulSoup(main_page_response.text, 'html.parser')
            title_tag = main_page_soup.find('title')
            if title_tag and title_tag.string:
                result['main_page_title'] = title_tag.string.strip()

        parsed_domain = urlparse(domain)
        base_domain = f"{parsed_domain.scheme}://{parsed_domain.netloc}"
        result['file_status'] = check_domain_file_status(base_domain)
        result['restore_status'] = check_website_restore_status(result['file_status'], main_page_response, main_page_soup)

        if main_page_response.status_code == 200:
            amp_link = main_page_soup.find('link', rel='amphtml')
            if amp_link and amp_link.has_attr('href'):
                result['amp_url'] = amp_link['href']
                try:
                    googlebot_headers = {'User-Agent': GOOGLEBOT_UA}
                    start_time = time.time()
                    googlebot_response = requests.get(result['amp_url'], headers=googlebot_headers, timeout=REQUEST_TIMEOUT, verify=False, allow_redirects=True)
                    end_time = time.time()
                    result['response_time_ms'] = f"{round((end_time - start_time) * 1000, 2):.2f}"
                    result['response_code'] = googlebot_response.status_code

                    browser_headers = {'User-Agent': BROWSER_UA}
                    browser_response = requests.get(result['amp_url'], headers=browser_headers, timeout=REQUEST_TIMEOUT, verify=False, allow_redirects=True)

                    if googlebot_response.status_code == 200 and browser_response.status_code == 200:
                        googlebot_soup = BeautifulSoup(googlebot_response.text, 'html.parser')
                        browser_soup = BeautifulSoup(browser_response.text, 'html.parser')

                        googlebot_text = googlebot_soup.get_text().strip()
                        browser_text = browser_soup.get_text().strip()

                        if googlebot_text != browser_text:
                            title_diff = False
                            content_diff = False

                            gb_title = googlebot_soup.find('title').get_text().strip() if googlebot_soup.find('title') else ""
                            br_title = browser_soup.find('title').get_text().strip() if browser_soup.find('title') else ""
                            if gb_title != br_title:
                                title_diff = True

                            gb_headings = [h.get_text().strip() for h in googlebot_soup.find_all(['h1', 'h2'])]
                            br_headings = [h.get_text().strip() for h in browser_soup.find_all(['h1', 'h2'])]
                            if gb_headings != br_headings:
                                content_diff = True

                            gb_paragraphs = [p.get_text().strip() for p in googlebot_soup.find_all('p')]
                            br_paragraphs = [p.get_text().strip() for p in browser_soup.find_all('p')]
                            if gb_paragraphs != br_paragraphs:
                                content_diff = True

                            if title_diff or content_diff:
                                result['amp_status'] = 'CLOAKING DETECTED'
                            else:
                                result['amp_status'] = 'VALID'
                        else:
                            result['amp_status'] = 'VALID'

                        title_tag = googlebot_soup.find('title')
                        if title_tag and title_tag.string:
                            result['amp_title'] = title_tag.string.strip()
                        else:
                            result['amp_title'] = 'No Title'

                        keywords = ['daftar', 'masuk', 'login', 'register', 'sign-up']
                        found_link = "Not Found"
                        for a_tag in googlebot_soup.find_all('a', href=True):
                            href = a_tag['href']
                            if href.startswith('/'):
                                base_url = urlparse(result['amp_url']).scheme + '://' + urlparse(result['amp_url']).netloc
                                href = base_url + href
                            if any(keyword in href.lower() for keyword in keywords):
                                found_link = href
                                break
                        result['daftar_masuk_link'] = found_link
                    else:
                        result['amp_status'] = f'INVALID ({googlebot_response.status_code})'

                except requests.exceptions.Timeout:
                    result['amp_status'] = 'TIMEOUT'
                    result['response_code'] = 'CTO'
                except requests.exceptions.SSLError:
                    result['amp_status'] = 'SSL ERROR'
                except requests.exceptions.ConnectionError:
                    result['amp_status'] = 'CONN ERROR'
                except requests.exceptions.RequestException:
                    result['amp_status'] = 'INVALID'
            else:
                result['amp_status'] = 'NOT FOUND'
        else:
            result['amp_status'] = 'DOMAIN ERROR'

    except requests.exceptions.Timeout:
        result['amp_status'] = 'TIMEOUT'
        result['response_code'] = 'CTO'
    except requests.exceptions.SSLError:
        result['amp_status'] = 'SSL ERROR'
    except requests.exceptions.ConnectionError:
        result['amp_status'] = 'CONN ERROR'
    except requests.exceptions.RequestException as e:
        result['amp_status'] = 'DOMAIN ERROR'

    return result

# --- FUNGSI UNTUK MEMBUAT TABEL ---
def generate_table(results_map, domains_to_check, widths):
    (domain_w, file_status_w, restore_status_w, main_title_w, status_w, code_w, time_w, amp_title_w, amp_url_w, daftar_w) = widths

    table = Table(show_header=True, header_style="bold cyan", box=box.SQUARE)
    table.add_column("DOMAIN", style="white", width=domain_w, no_wrap=True)
    table.add_column("FILE STATUS", width=file_status_w, overflow="fold", no_wrap=True)
    table.add_column("RESTORE STATUS", width=restore_status_w, no_wrap=True)
    table.add_column("MAIN TITLE", width=main_title_w, overflow="ellipsis", no_wrap=True)
    table.add_column("CLOAKING STATUS", width=status_w)
    table.add_column("CODE", width=code_w)
    table.add_column("TIME (ms)", width=time_w)
    table.add_column("PAGE TITLE", width=amp_title_w, overflow="ellipsis", no_wrap=True)
    table.add_column("PAGE URL", width=amp_url_w, no_wrap=True, overflow="ellipsis")
    table.add_column("DAFTAR/MASUK", width=daftar_w, overflow="ellipsis", no_wrap=True)

    for domain in domains_to_check:
        if domain in results_map:
            res = results_map[domain]
            status_colored = f"[{get_color_for_status(res['amp_status'])}]{res['amp_status']}[/{get_color_for_status(res['amp_status'])}]"
            code_colored = f"[{get_color_for_code(res['response_code'])}]{res['response_code']}[/{get_color_for_code(res['response_code'])}]"
            file_status_colored = f"[{get_color_for_file_status(res['file_status'])}]{res['file_status']}[/{get_color_for_file_status(res['file_status'])}]"
            restore_status_colored = f"[{get_color_for_restore_status(res['restore_status'])}]{res['restore_status']}[/{get_color_for_restore_status(res['restore_status'])}]"

            table.add_row(
                res['domain'],
                file_status_colored,
                restore_status_colored,
                res['main_page_title'],
                status_colored,
                code_colored,
                res['response_time_ms'],
                res['amp_title'],
                res['amp_url'],
                res['daftar_masuk_link']
            )
            table.add_row("─" * domain_w, "─" * file_status_w, "─" * restore_status_w, "─" * main_title_w, "─" * status_w, "─" * code_w, "─" * time_w, "─" * amp_title_w, "─" * amp_url_w, "─" * daftar_w, style="dim")
    return table

# --- LOOP UTAMA PEMANTAUAN ---
def main():
    logging.info("--- Memulai Cloaking Monitor ---")

    if not os.path.exists(DOMAIN_FILES_DIR):
        os.makedirs(DOMAIN_FILES_DIR)

    PERSISTENT_ERRORS = ('CONN ERROR', 'TIMEOUT')
    PERSISTENT_ERROR_DURATION = 300

    previous_states = {}
    last_alerted_times = {}
    persistent_error_start_times = {}
    previous_amp_urls = {}

    # Inisialisasi tabel kosong di Live mode
    with Live(Table(), screen=True) as live:
        while True:
            # 1. MUAT ULANG DOMAIN DI TIAP ITERASI (Dinamis)
            domains_to_check = load_domains(DOMAINS_FILE)
            if not domains_to_check:
                live.update(console.print("[yellow]File domains.txt kosong atau tidak ditemukan. Menunggu...[/yellow]"))
                time.sleep(5)
                continue

            # 2. HITUNG ULANG LEBAR KOLOM (Menyesuaikan jika ada domain panjang)
            max_domain_len = max(len(d) for d in domains_to_check)
            fixed_domain_width = max(max_domain_len, len("DOMAIN")) + 2
            
            # Lebar kolom lainnya (sesuai script asli Anda)
            column_widths = (fixed_domain_width, 45, 15, 15, 15, 4, 8, 15, 45, 35)

            # 3. RESET/INISIALISASI RESULTS MAP UNTUK SIKLUS INI
            results_map = {domain: {
                'domain': domain, 'file_status': 'Checking...', 'restore_status': '...', 'main_page_title': 'Checking...', 'amp_url': '-', 'amp_status': '-',
                'amp_title': '-', 'response_code': '-', 'response_time_ms': '-', 'daftar_masuk_link': '-'
            } for domain in domains_to_check}

            # Tampilkan tabel awal (Checking...)
            live.update(generate_table(results_map, domains_to_check, column_widths))

            with concurrent.futures.ThreadPoolExecutor() as executor:
                future_to_domain = {executor.submit(check_domain, domain): domain for domain in domains_to_check}

                for future in concurrent.futures.as_completed(future_to_domain):
                    result = future.result()
                    domain = result['domain']
                    results_map[domain] = result

                    # --- LOGIKA DETEKSI PERUBAHAN AMP URL ---
                    old_amp_url = previous_amp_urls.get(domain, 'N/A')
                    new_amp_url = result['amp_url']

                    result['amp_url_changed'] = False
                    if old_amp_url != new_amp_url and old_amp_url != 'Not Found' and new_amp_url != 'Not Found':
                        result['amp_url_changed'] = True
                        result['old_amp_url'] = old_amp_url
                        result['new_amp_url'] = new_amp_url
                        logging.info(f"AMP URL changed for {domain}: from '{old_amp_url}' to '{new_amp_url}'")

                    previous_amp_urls[domain] = new_amp_url

                    # --- LOGIKA STATUS DAN LOGGING ---
                    current_status = result['amp_status']
                    previous_status = previous_states.get(domain)

                    if previous_status != current_status:
                        log_message = (f"Domain: {result['domain']} | File Status: {result['file_status']} | Restore Status: {result['restore_status']} | "
                                       f"Cloaking Status: {result['amp_status']} | Page Code: {result['response_code']} | "
                                       f"Page Time: {result['response_time_ms']}ms | Page URL: {result['amp_url']} | "
                                       f"Page Title: {result['amp_title']} | Daftar/Masuk: {result['daftar_masuk_link']}")
                        if current_status == 'VALID':
                            logging.info(f"[OK] {log_message}" if previous_status else f"[INITIAL] {log_message}")
                        else:
                            logging.error(f"[PROBLEM] {log_message}" if previous_status else f"[INITIAL] {log_message}")
                        previous_states[domain] = current_status

                    # --- LOGIKA ALERT ---
                    is_problematic = (
                        result['response_code'] in [403, 500, 502, 501, 503] or
                        result['amp_status'] in ['CLOAKING DETECTED', 'DOWN', 'ERROR', 'INVALID', 'SSL ERROR', 'NOT FOUND'] or
                        result['amp_status'] in PERSISTENT_ERRORS or
                        any(keyword in result['file_status'] for keyword in ["Missing", "Error", "Timeout", "Conn Error", "Dir Not Found"]) or
                        result['restore_status'] == 'RESTORED' or
                        result.get('amp_url_changed', False)
                    )

                    if is_problematic:
                        current_time = time.time()
                        should_send_alert = False

                        if result['amp_status'] in PERSISTENT_ERRORS:
                            if domain in persistent_error_start_times:
                                tracked_info = persistent_error_start_times[domain]
                                if tracked_info['status'] != result['amp_status']:
                                    persistent_error_start_times[domain] = {'status': result['amp_status'], 'start_time': current_time}
                                else:
                                    if current_time - tracked_info['start_time'] >= PERSISTENT_ERROR_DURATION:
                                        should_send_alert = True
                                        persistent_error_start_times[domain]['start_time'] = current_time
                            else:
                                persistent_error_start_times[domain] = {'status': result['amp_status'], 'start_time': current_time}
                        else:
                            last_alert_time = last_alerted_times.get(domain, 0)
                            if current_time - last_alert_time >= ALERT_COOLDOWN_SECONDS:
                                should_send_alert = True
                            if domain in persistent_error_start_times:
                                del persistent_error_start_times[domain]

                        if should_send_alert:
                            send_telegram_alert(domain, result)
                            last_alerted_times[domain] = current_time

                    if result['amp_status'] == 'VALID':
                        if domain in persistent_error_start_times:
                            del persistent_error_start_times[domain]

                    # Update tampilan tabel secara real-time saat satu thread selesai
                    live.update(generate_table(results_map, domains_to_check, column_widths))

            time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\n[green]--- Monitor dihentikan oleh pengguna. ---[/green]")
        sys.exit(0)
    except Exception as e:
        console.print(f"\n[red]Terjadi error tak terduga: {e}[/red]")
        sys.exit(1)